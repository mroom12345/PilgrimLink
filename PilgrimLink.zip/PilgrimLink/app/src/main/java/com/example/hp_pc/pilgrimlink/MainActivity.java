package com.example.hp_pc.pilgrimlink;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {
    JSONArray jsonArray=null;
    Number[] numbersArray;
ImageView c1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new GetNumber().execute();
        ImageView m=(ImageView)findViewById(R.id.start);
        m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              Intent i = new Intent(MainActivity.this,Languages.class);
              startActivity(i);
            }
        });
    }
    private class GetNumber extends AsyncTask<String, Integer, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {

            try {
                URL url =new URL("http://10.0.3.2/getnum.php");
                URLConnection urlConnection=url.openConnection();

                 InputStreamReader inputStreamReader =new InputStreamReader(urlConnection.getInputStream());
                 BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                 String ligne;
                 while((ligne = bufferedReader.readLine() )!=null){
                     jsonArray=new JSONArray(ligne);

                 }

                Log.d("result" ,jsonArray.toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Gson gson=new Gson();
            numbersArray=gson.fromJson(jsonArray.toString(),Number[].class);
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }
    }

}
