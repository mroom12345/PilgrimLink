package com.example.hp_pc.pilgrimlink;

public class number {

        private int campain_id;
        private String campain_name;
        private int number;

    public number(int campain_id, String campain_name, int number) {
        this.campain_id = campain_id;
        this.campain_name = campain_name;
        this.number = number;
    }

    public number(int number) {
        this.number = number;
    }

}
