package com.example.hp_pc.pilgrimlink;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class Pligrim extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pligrim);

        Button yes=(Button)findViewById(R.id.yes_button);
        Button no=(Button)findViewById(R.id.no_button);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1= new Intent(Pligrim.this,CampaignNumber.class);
                startActivity(intent1);
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2= new Intent(Pligrim.this,MainActivity.class);
                startActivity(intent2);
            }
        });
    }
}

